package register;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.sql.Connection;
import java.sql.Statement;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.image.Image;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import tools.Instruction;

public class RegisterView extends Application{
    private Pane pane=new Pane();
    private Label Lnick=new Label("* �ǳ�:"),birthday=new Label("* ����:"),sex=new Label("* �Ա�:"),Lyear=new Label("��"),Lmonth=new Label("��"),Lday=new Label("��"),
    		Lpass=new Label("* ����:"),Lconfirm=new Label("* ȷ������:");
	private TextField nickName=new TextField();
	private ComboBox<String> year=new ComboBox<>(),month=new ComboBox<>(),day=new ComboBox<>();
	private PasswordField password=new PasswordField(),confirmPassword=new PasswordField();
	private Button go=new Button("ע��");
	private RadioButton boy=new RadioButton("��"),girl=new RadioButton("Ů");
	private ToggleGroup group=new ToggleGroup();
    private Label tip=new Label("");
	public static void main(String args[]) {
		RegisterView.launch(args);
	}
	@Override
	public void start(Stage primaryStage) throws Exception {
		for(Integer i=1879;i<=2018;i++)
			year.getItems().add(i.toString());
		for(Integer i=1;i<=12;i++)
			month.getItems().add(i.toString());
		for(Integer i=1;i<=31;i++)
			day.getItems().add(i.toString());
		boy.setToggleGroup(group);
		girl.setToggleGroup(group);
		//�趨λ��
		nickName.setLayoutX(200);
		nickName.setLayoutY(100);
		year.setLayoutX(200);
		year.setLayoutY(150);
		month.setLayoutX(330);
		month.setLayoutY(150);
		day.setLayoutX(435);
		day.setLayoutY(150);
		birthday.setLayoutX(150);
		birthday.setLayoutY(155);
		Lnick.setLayoutX(150);
		Lnick.setLayoutY(105);
		Lyear.setLayoutX(300);
		Lyear.setLayoutY(155);
		Lmonth.setLayoutX(405);
		Lmonth.setLayoutY(155);
		Lday.setLayoutX(510);
		Lday.setLayoutY(155);
		boy.setLayoutX(220);
		boy.setLayoutY(200);
		girl.setLayoutX(300);
		girl.setLayoutY(200);
		sex.setLayoutX(150);
		sex.setLayoutY(200);
		password.setLayoutX(200);
		password.setLayoutY(250);
		confirmPassword.setLayoutX(200);
		confirmPassword.setLayoutY(300);
		Lpass.setLayoutX(150);
		Lpass.setLayoutY(255);
		Lconfirm.setLayoutX(120);
		Lconfirm.setLayoutY(305);
		go.setLayoutX(250);
		go.setLayoutY(400);
		tip.setLayoutX(250);
		tip.setLayoutY(360);
		
		go.setOnAction(e->{
			try {
				signup();
			} catch (UnknownHostException e1) {

				e1.printStackTrace();
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		});
		pane.getChildren().addAll(nickName,year,month,day,birthday,Lnick,Lmonth,Lyear,Lday,boy,girl,sex,password,
				Lpass,Lconfirm,confirmPassword,go,tip);
		Scene scene=new Scene(pane,580,480);
		primaryStage.getIcons().add(new Image("/images/registericon.png"));
		pane.setStyle("-fx-background-image: url(\"/images/bg1.png\");");
		primaryStage.setTitle("ע��");
		primaryStage.setScene(scene);
		primaryStage.show();
	}
	private void signup() throws UnknownHostException, IOException {
		Socket socket=new Socket("192.168.1.16",8000);
    	DatagramSocket dsocketSend=new DatagramSocket();
    	DatagramSocket dsocketRece=new DatagramSocket(10001);
    	//��ȡע����Ϣ
		String nkname = nickName.getText().trim();
		String pw = password.getText().trim();
		String pwConfirm=confirmPassword.getText().trim();
		String sex = null;
		String y = year.getValue();
		String m = month.getValue();
		String d = day.getValue();
		if(boy.isSelected()) {
			sex = "��";
		}
        if(girl.isSelected()) {
        	sex = "Ů";
        }
        //������ʾ
		if(nkname==null||pw.isEmpty()||sex==null||y==null||m==null||d==null||pwConfirm.isEmpty()) {
			tip.setText("�벹ȫ��Ϣ��");
		}
		else if(!pw.equals(pwConfirm)){
			tip.setText("������������벻ͬ��");
		}
		//ע��ɹ�
		else {
        Instruction ins=new Instruction("1","1",socket.getInetAddress().toString(),"0","6");
        ins.addParemeter(nkname);
        ins.addParemeter(pw);
        ins.addParemeter(sex);
        ins.addParemeter(y);
        ins.addParemeter(m);
        ins.addParemeter(d);
        byte[] message=ins.toString().getBytes();
        DatagramPacket sendPack=new DatagramPacket(message,message.length,InetAddress.getByName("192.168.1.16"),10003);
        dsocketSend.send(sendPack);
		while(true)
		{
			byte[] buf=new byte[1024];
        	DatagramPacket dp=new DatagramPacket(buf,buf.length);
        	try {
				dsocketRece.receive(dp);
			} catch (IOException e) {
				e.printStackTrace();
			}
        	String text=new String(dp.getData(),0,dp.getLength());
        	if(!text.equals("0")) {
        		SuccessRegister open=new SuccessRegister(text);
        		try {
					open.start(new Stage());
				} catch (Exception e) {
					e.printStackTrace();
				}
        	}
        	break;
		}
		}
		socket.close();
		dsocketSend.close();
		dsocketRece.close();
	}	
}

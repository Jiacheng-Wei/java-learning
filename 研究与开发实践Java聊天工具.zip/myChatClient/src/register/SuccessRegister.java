package register;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.image.Image;
import javafx.scene.layout.Pane;
import javafx.scene.text.Font;
import javafx.stage.Stage;

public class SuccessRegister extends Application{
	private Pane pane=new Pane();
	private Label label=new Label();
	private String OOnumber;

	public SuccessRegister(String o) {
		this.OOnumber=o;
	}
	@Override
	public void start(Stage primaryStage) throws Exception {
		label.setText("����OO���ǣ�"+OOnumber);
		label.setFont(Font.font ("Magneto", 24));
		pane.getChildren().addAll(label);
		pane.setStyle("-fx-background-color: linear-gradient(to right,#c2e9fb,#dfe9f3);");
		Scene scene=new Scene(pane,400,200);
		primaryStage.getIcons().add(new Image("/images/registericon.png"));
		primaryStage.setTitle("ע��ɹ�");
		primaryStage.setScene(scene);
		primaryStage.show();
		
		
	}
       
}

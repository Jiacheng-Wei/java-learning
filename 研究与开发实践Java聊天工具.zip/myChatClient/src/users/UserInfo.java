package users;

import java.util.Date;

public class UserInfo {
	private String IpAdress;
	private String OOnumber;
	private String Status;
	private int Port;
	private Date loginDate;
	
	public UserInfo(){
		super();
	}
    public UserInfo(String ip,String OOnum,String status,int port){
    	super();
    	this.IpAdress=ip;
    	this.OOnumber=OOnum;
    	this.Status=status;
    	this.Port=port;
    	this.loginDate=new Date();
    }
}

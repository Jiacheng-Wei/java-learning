package chat;

import java.util.ArrayList;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextArea;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import tools.Message;

public class History extends Application{
	private Pane pane=new Pane();
	private ScrollPane scrollpane=new ScrollPane();
	private TextArea ta=new TextArea();
	private Button close=new Button("�ر�");

	private ArrayList<Message> k=new ArrayList<>();
	private String mynick=null;
	private String yournick=null;
	private int myOO=0;
	public History(ArrayList<Message> e,String my,String you,int myoo) {
		this.k=e;
		this.mynick=my;
		this.yournick=you;
		this.myOO=myoo;
	}
	public static void main(String[] args) {
		
		History.launch(args);
	}
	@Override
	public void start(Stage primaryStage) throws Exception {
		
		scrollpane.setContent(ta);
		ta.setMaxWidth(450);
		ta.setLayoutX(25);
		ta.setLayoutY(50);
		close.setLayoutX(200);
		close.setLayoutY(300);

		for(int i=0;i<k.size();i++) {
			if(this.myOO==k.get(i).getfromID())
			ta.appendText(this.mynick+" "+k.get(i).getDate()+"\n"+k.get(i).getContent()+"\n");
			else
			ta.appendText(this.yournick+" "+k.get(i).getDate()+"\n"+k.get(i).getContent()+"\n");
		}
		pane.getChildren().addAll(close,ta);
		Scene scene=new Scene(pane,500,400);
		primaryStage.setScene(scene);
		primaryStage.show();
	}

}

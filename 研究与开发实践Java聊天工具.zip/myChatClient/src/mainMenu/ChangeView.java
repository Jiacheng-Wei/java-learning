package mainMenu;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.image.Image;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import register.SuccessRegister;
import tools.Instruction;


public class ChangeView extends Application{
	private Pane pane=new Pane();
    private Label Lnick=new Label("�ǳ�:"),birthday=new Label("����:"),sex=new Label("�Ա�:"),Lyear=new Label("��"),Lmonth=new Label("��"),Lday=new Label("��"),
    		Lpass=new Label("״̬:");
	private TextField nickName=new TextField();
	private ComboBox<String> status=new ComboBox<String>();
	private ComboBox<String> year=new ComboBox<>(),month=new ComboBox<>(),day=new ComboBox<>();
	private PasswordField password=new PasswordField(),confirmPassword=new PasswordField();
	private Button go=new Button("ȷ��");
	private Button changePassword=new Button("�޸�����");
	private RadioButton boy=new RadioButton("��"),girl=new RadioButton("Ů");
	private ToggleGroup group=new ToggleGroup();
    private Label tip=new Label("");
    private Socket socket;
	private DatagramSocket  sendSocket;
	private DatagramSocket  receSocket;
	private String OOnumber;
	
    public ChangeView() {
    	super();
    }
    public ChangeView(String oo,String nick,Integer year,Integer month,Integer day,String sex,String sta,Socket s,DatagramSocket ds,DatagramSocket dr) {
    	this.status.setValue(sta);;
    	this.nickName.setText(nick);
    	this.year.setValue(year.toString());
    	this.month.setValue(month.toString());
    	this.day.setValue(day.toString());
    	if(sex.equals("��"))
    		this.boy.setSelected(true);
    	else
    		this.girl.setSelected(true);
    	this.socket=s;
    	this.sendSocket=ds;
    	this.receSocket=dr;
    	this.OOnumber =oo;
    }
	public static void main(String[] args) {
		ChangeView.launch(args);

	}

	@Override
	public void start(Stage primaryStage) throws Exception {

		boy.setToggleGroup(group);
		girl.setToggleGroup(group);
		for(Integer i=1879;i<=2018;i++)
			this.year.getItems().add(i.toString());
		for(Integer i=1;i<=12;i++)
			this.month.getItems().add(i.toString());
		for(Integer i=1;i<=31;i++)
			this.day.getItems().add(i.toString());
		this.status.getItems().addAll("����","����","�뿪","æµ");
		//�趨λ��
		nickName.setLayoutX(200);
		nickName.setLayoutY(100);
		year.setLayoutX(200);
		year.setLayoutY(150);
		month.setLayoutX(330);
		month.setLayoutY(150);
		day.setLayoutX(435);
		day.setLayoutY(150);
		birthday.setLayoutX(150);
		birthday.setLayoutY(155);
		Lnick.setLayoutX(150);
		Lnick.setLayoutY(105);
		Lyear.setLayoutX(300);
		Lyear.setLayoutY(155);
		Lmonth.setLayoutX(405);
		Lmonth.setLayoutY(155);
		Lday.setLayoutX(510);
		Lday.setLayoutY(155);
		boy.setLayoutX(220);
		boy.setLayoutY(200);
		girl.setLayoutX(300);
		girl.setLayoutY(200);
		sex.setLayoutX(150);
		sex.setLayoutY(200);
		status.setLayoutX(200);
		status.setLayoutY(250);
		Lpass.setLayoutX(150);
		Lpass.setLayoutY(255);

		changePassword.setLayoutX(350);
		changePassword.setLayoutY(400);
		go.setLayoutX(150);
		go.setLayoutY(400);
		tip.setLayoutX(250);
		tip.setLayoutY(360);
		pane.getChildren().addAll(nickName,year,month,day,birthday,Lnick,Lmonth,Lyear,Lday,boy,girl,sex,
				Lpass,status,go,tip,changePassword);
		Scene scene=new Scene(pane,580,430);
		pane.setStyle("-fx-background-image: url(\"/images/change.png\");");
		primaryStage.getIcons().add(new Image("/images/info.png"));
		primaryStage.setTitle("�޸���Ϣ");
		primaryStage.setScene(scene);
		primaryStage.show();
		go.setOnAction(e->{
			try {
				change();
			} catch (IOException e1) {
				e1.printStackTrace();
			}
			primaryStage.close();
		});
		changePassword.setOnAction(e->changePassword());
	}
    public void  change() throws IOException {
    	String nkname = nickName.getText();
		String sex = null;
		String y = year.getValue();
		String m = month.getValue();
		String d = day.getValue();
		String sta=status.getValue();
		if(boy.isSelected()) {
			sex = "��";
		}
        if(girl.isSelected()) {
        	sex = "Ů";
        }
        //������ʾ
		if(nkname.isEmpty()||sex==null||y==null||m==null||d==null) {
			tip.setText("�벹ȫ��Ϣ��");
		}
		else {
		        Instruction ins=new Instruction("2","2",socket.getLocalAddress().toString(),this.OOnumber,"6");
		        ins.addParemeter(nkname);
		        ins.addParemeter(sex);
		        ins.addParemeter(y);
		        ins.addParemeter(m);
		        ins.addParemeter(d);
		        ins.addParemeter(sta);
		        ins.send(sendSocket);
		}
    }
    public void changePassword() {
    	ChangePassword open=new ChangePassword(this.OOnumber,this.socket,this.sendSocket,this.receSocket);
    	try {
			open.start(new Stage());
		} catch (Exception e) {
			e.printStackTrace();
		}
    }
}

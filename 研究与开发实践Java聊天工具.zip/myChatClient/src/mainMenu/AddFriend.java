package mainMenu;

import java.io.IOException;
import java.net.DatagramSocket;
import java.net.Socket;
import java.util.ArrayList;

import javafx.application.Application;
import javafx.collections.ObservableList;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.image.Image;
import javafx.scene.layout.Pane;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import tools.Instruction;

public class AddFriend extends Application{
	
    private Pane pane = new Pane();
    private String nick;
    private Button confirm = new Button("ȷ��");
    private Button cancel = new Button("����");
    private Label label=new Label();
    private Label result=new Label("�ѷ��ͺ�������");
	private Socket socket;
	private DatagramSocket sendSocket;
	private DatagramSocket receSocket;
	private String myoonumber;
	private String youroonumber;
	private ListView<String> lv;
    private ObservableList<String> str ;
	
    public AddFriend(String myoo,String oo,String nick,Socket s,DatagramSocket ds,DatagramSocket dr,ListView<String> lv,ObservableList<String> str) {
    	label.setText("��ȷ��Ҫ�����û� "+oo+":"+nick+" Ϊ������?");
    	this.nick=nick;
    	this.myoonumber=myoo;
    	this.youroonumber=oo;
		this.socket=s;
		this.sendSocket=ds;
		this.receSocket=dr;
		this.lv=lv;
		this.str=str;
    }
	public static void main(String[] args) {
		AddFriend.launch(args);
	}

	@Override
	public void start(Stage primaryStage) throws Exception {
		pane.getChildren().addAll(confirm,cancel,label);
		pane.getChildren().addAll(confirm,cancel,label);
		label.setLayoutX(80);
		label.setLayoutY(100);
		confirm.setLayoutX(120);
		confirm.setLayoutY(200);
		cancel.setLayoutX(220);
		cancel.setLayoutY(200);
		label.setFont(Font.font ("΢���ź�", 14));
    	Scene scene = new Scene(pane,400,250);
    	primaryStage.setTitle("���Ӻ���");
		primaryStage.setScene(scene);
		primaryStage.show();
		pane.setStyle("-fx-background-image: url(\"/images/addbg.png\");");
		primaryStage.getIcons().add(new Image("/images/search.png"));
		
		confirm.setOnAction(e->addfriend());
		cancel.setOnAction(e->{primaryStage.close();});
	}
	public void addfriend() {
		Instruction ins=new Instruction("2","5",socket.getLocalAddress().toString(),this.myoonumber,"1");
		ins.addParemeter(youroonumber);
		try {
			ins.send(sendSocket);
		} catch (IOException e) {
			e.printStackTrace();
		}
		str.add(this.nick+"("+this.youroonumber+")");
		lv.setItems(null);  
		lv.setItems(str);
		
	}
}

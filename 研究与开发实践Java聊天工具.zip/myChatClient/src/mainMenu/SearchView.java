package mainMenu;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.Socket;
import java.util.ArrayList;

import javafx.application.Application;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.Priority;
import javafx.stage.Stage;
import register.SuccessRegister;
import tools.Instruction;

public class SearchView extends Application{
	private Pane pane=new Pane();
	private Button searchFriends=new Button("����");
	private TextField tx=new TextField();
	private ListView<String> list=new ListView();
	private Socket socket;
	private DatagramSocket  sendSocket;
	private DatagramSocket  receSocket;
	private String oonumber;
	ObservableList<String> items=FXCollections.observableArrayList();
	private ListView<String> lv;
    private ObservableList<String> str ;

	public static void main(String[] args) {
		SearchView.launch(args);
	}

	public SearchView(String oo,Socket s,DatagramSocket ds,DatagramSocket dr,ListView<String> lv,ObservableList<String> str) {
		this.oonumber=oo;
		this.socket=s;
		this.sendSocket=ds;
		this.receSocket=dr;
		this.lv=lv;
		this.str=str;
	}
	@Override
	public void start(Stage primaryStage) throws Exception {

		
		tx.setLayoutX(20);
		tx.setLayoutY(40);
		list.setMinWidth(400);
		list.setLayoutX(50);
		list.setLayoutY(80);
		list.setItems(items);
		searchFriends.setLayoutX(250);
		searchFriends.setLayoutY(40);
		pane.getChildren().addAll(searchFriends,tx,list);
		pane.setStyle("-fx-background-image: url(\"/images/searchbg.png\");");
		Scene scene =new Scene(pane,400,500);
		primaryStage.getIcons().add(new Image("/images/search.png"));
		primaryStage.setTitle("���Һ���");
		primaryStage.setScene(scene);
		primaryStage.show();
		searchFriends.setOnAction(e->{
			try {
				searchByOOnumber();
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		});
		list.getSelectionModel().selectedItemProperty().addListener(e->{
			String s=(String) list.getSelectionModel().selectedItemProperty().get();
			selectFriend(s.substring(0, s.indexOf(":")),s.substring(s.indexOf(":")+1));
		});
	}
    public void searchByOOnumber() throws IOException {
    	String OOnumber=tx.getText().trim();
    	Instruction searchInstruction=new Instruction("2","1",socket.getLocalAddress().toString(),this.oonumber,"1");
    	searchInstruction.addParemeter(OOnumber);
    	byte[] bt=searchInstruction.toString().getBytes();
    	DatagramPacket pack=new DatagramPacket(bt,bt.length,InetAddress.getByName("192.168.1.16"),10003);
    	sendSocket.send(pack);
    	while(true) {
    		byte[] buf=new byte[1024];
        	DatagramPacket dp=new DatagramPacket(buf,buf.length);
        	try {
				receSocket.receive(dp);
			} catch (IOException e) {
				e.printStackTrace();
			}
        	String text=new String(dp.getData(),0,dp.getLength());
        	System.out.println(text);
        	if(!text.equals("0")) {
        		items.add(text);
        		list.setItems(null);  
        		list.setItems(items); 
        	}
        	break;
    	}
    }
    public void selectFriend(String oonumber,String nick) {
    	AddFriend open=new AddFriend(this.oonumber,oonumber,nick,this.socket,this.sendSocket,this.receSocket,this.lv,this.str);
    	try {
			open.start(new Stage());
		} catch (Exception e) {
			e.printStackTrace();
		}
    }
}

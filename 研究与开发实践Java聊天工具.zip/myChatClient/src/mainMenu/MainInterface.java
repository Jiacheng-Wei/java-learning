package mainMenu;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.ArrayList;

import chat.History;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Pos;
import javafx.geometry.Side;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.control.TextArea;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import tools.Instruction;
import tools.Message;

public class MainInterface extends Application{
	private TabPane tp = new TabPane();
    private HBox hBox = new HBox();
    private BorderPane bp = new BorderPane();
    private ScrollPane sp = new ScrollPane();
    private VBox vBox = new VBox();
    private HBox buttonBox = new HBox();
    private Text nkname = new Text(); //��ʾ�ǳ�
    private ImageView iv_chat = new ImageView();
    private ImageView iv_friend = new ImageView();
    private ImageView iv_group = new ImageView();
    private Menu menu = new Menu("+");
    private MenuBar mb = new MenuBar();
    private MenuItem addfriend = new MenuItem("���Ӻ���");
	private MenuItem addgroup = new MenuItem("����Ⱥ");
	private MenuItem modifyInfo = new MenuItem("�޸ĸ�����Ϣ");
	private Tab tab1 = new Tab();
	private Tab tab2 = new Tab();
	private Tab tab3 = new Tab();
	private ListView<String> lv = new ListView<>();
	private ArrayList<String> friends = new ArrayList<>();
    private ObservableList<String> str = FXCollections.observableArrayList();
    private TextArea ta1 = new TextArea();
    private TextArea ta2 = new TextArea();
    private Button bt = new Button("����");
    private Button ima = new Button("ͼƬ");
    private Button his = new Button("��ʷ��¼");
    private FileChooser fileChooser = new FileChooser();
    
    private String nickName=new String();
	private Socket socket;//���ӷ�����
	private DatagramSocket sendSocket;//����ָ��
	private DatagramSocket receSocket;//���շ������ظ�
	private DatagramSocket receMeceSocket;//������Ϣ
	private String OOnumber;//���û���String����OOnumber
	private ArrayList<String> parameter;//���շ��������ص�ָ�����
	private ArrayList<String> friendlist;//�����б�
	private ArrayList<Message> unreadMessage;//δ����Ϣ
	private ArrayList<Message> newReceiveMessage=new ArrayList<Message>();//δ����Ϣ
	private int intoonumber;//int���͵�OOnumber
	private String target=new String();

	public MainInterface(String oo,ArrayList<String> e,ArrayList<Message> k,String nick) {
		this.OOnumber=oo;
		this.friendlist=e;
		this.unreadMessage=k;
		this.intoonumber=Integer.valueOf(this.OOnumber);
		this.nickName=nick;
	}
    
	public static void main(String[] args) {
		// TODO Auto-generated method stub
        MainInterface.launch(args);
	}
    public void start(Stage primaryStage) throws UnknownHostException, IOException {
    	nkname.setText(this.nickName);
    	nkname.setFont(Font.font("��Բ", FontWeight.BOLD, 30));
    	iv_chat.setImage(new Image("/images/chat2.png"));
    	iv_friend.setImage(new Image("/images/friend2.png"));
    	iv_group.setImage(new Image("/images/chat4.png"));
    	iv_chat.setFitHeight(40);
    	iv_chat.setFitWidth(40);
    	iv_friend.setFitHeight(40);
    	iv_friend.setFitWidth(40);
    	iv_group.setFitHeight(40);
    	iv_group.setFitWidth(40);
    	tab1.setGraphic(iv_chat);
    	tab2.setGraphic(iv_friend);
    	tab3.setGraphic(iv_group);
    	mb.getMenus().add(menu);
		mb.setStyle("-fx-background-color:white");
		menu.getItems().addAll(addfriend,addgroup,modifyInfo);
		menu.setStyle("-fx-background-color:white");
		hBox.getChildren().addAll(nkname,mb);
		buttonBox.getChildren().addAll(bt,his);
		
		
		//initFriendlist();
        socket=new Socket("192.168.1.16",8000);
        sendSocket=new DatagramSocket();
        receSocket=new DatagramSocket(10001);//10001�˿ڽ��շ������ظ�
        receMeceSocket=new DatagramSocket(10002);//10002�˿ڽ���������Ϣ
		for(int i=0;i<friendlist.size();i++) {
			str.add(friendlist.get(i));
    		lv.setItems(null);  
    		lv.setItems(str); 
		}
		lv.setItems(str);
		lv.setPrefSize(350, 600);
        sp.setContent(lv);
        tab1.setContent(sp);
        
        ta1.setEditable(false);
        ta2.setEditable(true);
        ta1.setPrefSize(350, 300);
        ta2.setPrefSize(350, 220);
        vBox.getChildren().addAll(ta1,ta2,buttonBox);
        vBox.setAlignment(Pos.CENTER_RIGHT);
        vBox.setSpacing(20);
        
        //setOnAction
        primaryStage.setOnCloseRequest(e->{
        	try {close();} catch (IOException e2) {e2.printStackTrace();}
        	});
        addfriend.setOnAction(e->{
        	search();
        });
        addgroup.setOnAction(e->{
        	
        });
        modifyInfo.setOnAction(e->{
        	try {
        		change();
        	} catch (IOException e1) {
        		e1.printStackTrace();
        	}
        });
        bt.setOnAction(e->{
        	try {
				sendMessage();
			} catch (IOException e1) {
				e1.printStackTrace();
			}
        });
        lv.getSelectionModel().selectedItemProperty().addListener(e->{
        	changeTarget();
        });
        his.setOnAction(e->{
        	try {
				history();
			} catch (IOException e1) {
				// TODO �Զ����ɵ� catch ��
				e1.printStackTrace();
			}
        });
        ima.setOnAction(
            e -> {
            	FileChooser fileChooser = new FileChooser();//����һ���ļ�ѡ����ʵ��
                fileChooser.getExtensionFilters().addAll(
                        new FileChooser.ExtensionFilter("All Images", "*.*"),
                        new FileChooser.ExtensionFilter("JPG", "*.jpg"),
                        new FileChooser.ExtensionFilter("PNG", "*.png")
                    );
            	File selectedFile = fileChooser.showOpenDialog(primaryStage);
            	String path=selectedFile.getPath();
            	
        });
		new Thread(() -> receMessage()).start();
		
		tab1.setClosable(false);
    	tab2.setClosable(false);
    	tab3.setClosable(false);
    	tab1.setStyle("-fx-background-color:white");
    	tab2.setStyle("-fx-background-color:white");
    	tab3.setStyle("-fx-background-color:white");
    	tp.getTabs().addAll(tab1,tab3);
    	tp.setSide(Side.LEFT);
    	bp.setTop(hBox);
    	bp.setCenter(tp);
    	bp.setRight(vBox);
    	bp.getStyleClass().add("sceneroot");
    	Scene scene = new Scene(new Group(),750,630,Color.WHITE);
    	Group sceneroot = (Group)scene.getRoot();
    	sceneroot.getChildren().add(bp);
    	primaryStage.setTitle("OICO");
		primaryStage.setScene(scene);
		primaryStage.show();
    }
    
    //���ܺ���
	public void close() throws IOException {
		if(this.newReceiveMessage.size()!=0) {
		Instruction ins=new Instruction("1","3",socket.getLocalAddress().toString(),this.OOnumber,"0");
		int paranum=this.newReceiveMessage.size();
		ins.setParmNum(paranum);
		for(int i=0;i<paranum;i++) {
			ins.addParemeter(this.newReceiveMessage.get(i).toString());
		}
		ins.send(sendSocket);
		}
		this.sendSocket.close();
		this.receMeceSocket.close();
		this.receSocket.close();
		this.socket.close();
	}
	//�������ѿͻ��˹���
    public void search() {
    	SearchView open=new SearchView(this.OOnumber,socket,sendSocket,receSocket,this.lv,this.str);
    	try {
			open.start(new Stage());
		} catch (Exception e) {
			e.printStackTrace();
		}
    }
    //�޸ĸ�����Ϣ�ͻ��˹���
    public void change() throws IOException {
    	Instruction ins=new Instruction("2","3",socket.getLocalAddress().toString(),this.OOnumber,"0");
        ins.send(sendSocket);
    	while(true)
		{
			byte[] buf=new byte[1024];
        	DatagramPacket dp=new DatagramPacket(buf,buf.length);
        	try {
				receSocket.receive(dp);
			} catch (IOException e) {
				e.printStackTrace();
			}
        	String text=new String(dp.getData(),0,dp.getLength());
        	Instruction reAction=Instruction.toInstruction(text);
        	parameter=reAction.getParameterList();
        	break;
		}
    	ChangeView open=new ChangeView(this.OOnumber,parameter.get(0),
    			Integer.valueOf(parameter.get(1)),Integer.valueOf(parameter.get(2)),Integer.valueOf(parameter.get(3)),
    			parameter.get(4),parameter.get(5),this.socket,this.sendSocket,this.receSocket);
    	try {
			open.start(new Stage());
		} catch (Exception e) {
			e.printStackTrace();
		}
    }
    //������Ϣ
    public void sendMessage() throws IOException {
    	if(!this.target.equals(""))
    	{Instruction ins=new Instruction("3","1",socket.getLocalAddress().toString(),this.OOnumber,"2");
    	ins.addParemeter(this.target);
    	ins.addParemeter(ta2.getText());
    	if(!ta2.getText().equals("")){
        ta1.appendText(this.nickName+"("+this.intoonumber+") "+ins.getDate()+"\n"+ta2.getText()+"\n");
        ins.send(sendSocket);
        }
    	ta2.clear();
    	}
    }
    //������Ϣ
    public void receMessage() {
    	while(!receMeceSocket.isClosed()) {
    		byte[] buf=new byte[1024];
        	DatagramPacket dp=new DatagramPacket(buf,buf.length);
        	try {
				receMeceSocket.receive(dp);
			} catch (IOException e) {
				e.printStackTrace();
				break;
			}
        	String text=new String(dp.getData(),0,dp.getLength());
        	Instruction reInstruction=Instruction.toInstruction(text);
        	ArrayList<String> newParameter=reInstruction.getParameterList();
    		int fid=Integer.valueOf(reInstruction.getOOnumber());
    		int tid=Integer.valueOf(newParameter.get(0));
        	if(reInstruction.getOOnumber().equals(this.target)) {
        		
        		ta1.appendText(lv.getSelectionModel().selectedItemProperty().getValue()+" "+reInstruction.getDate()+"\n"+newParameter.get(1)+"\n");
        		
        		Message g=new Message(fid,tid,newParameter.get(1),1);
        		g.setDate(reInstruction.getDate());
        		this.newReceiveMessage.add(g);
        	}
        	else {
        		Message g=new Message(fid,tid,newParameter.get(1),0);
        		g.setDate(reInstruction.getDate());
        		this.newReceiveMessage.add(g);
        	}
    	}
    }
    //�л�����
    public void changeTarget() {
    	this.ta1.clear();
    	this.target=Instruction.getOOnumberFromNick(lv.getSelectionModel().selectedItemProperty().getValue());
    	int intTarget=Integer.valueOf(this.target);
    	for(int i=0;i<this.unreadMessage.size();i++) {
    		if(this.unreadMessage.get(i).getfromID()==intTarget&&this.unreadMessage.get(i).getStatus()==0) {
    			ta1.appendText(lv.getSelectionModel().selectedItemProperty().getValue()+" "+this.unreadMessage.get(i).getDate()+"\n"+this.unreadMessage.get(i).getContent()+"\n");
    			this.unreadMessage.get(i).setStatus(1);
    		}
    	}
    	for(int i=0;i<this.newReceiveMessage.size();i++) {
    		if(this.newReceiveMessage.get(i).getfromID()==intTarget&&this.newReceiveMessage.get(i).getStatus()==0) {
    			ta1.appendText(lv.getSelectionModel().selectedItemProperty().getValue()+" "+this.newReceiveMessage.get(i).getDate()+"\n"+this.newReceiveMessage.get(i).getContent()+"\n");
    			this.newReceiveMessage.get(i).setStatus(1);
    		}
    	}
    }
    public void history() throws IOException {
    	if(!this.target.equals("")) {
    	String mynick=this.nickName+"("+this.OOnumber+")";
    	String yournick=this.lv.getSelectionModel().selectedItemProperty().getValue();
    	Instruction ins=new Instruction("3","2",socket.getLocalAddress().toString(),this.OOnumber,"1");
    	ins.addParemeter(this.target);
    	ins.send(sendSocket);
    	ArrayList<Message> k=new ArrayList<>();
    	while(true) {
    			byte[] buf=new byte[4096];
            	DatagramPacket dp=new DatagramPacket(buf,buf.length);
            	try {
    				receSocket.receive(dp);
    			} catch (IOException e) {
    				e.printStackTrace();
    			}
            	String text=new String(dp.getData(),0,dp.getLength());
            	Instruction reAction=Instruction.toInstruction(text);
            	parameter=reAction.getParameterList();
            	for(int i=0;i<parameter.size();i++) {
            		k.add(Message.toMessage(parameter.get(i)));

            	}
            	break;
    	}
    	History open=new History(k,mynick,yournick,this.intoonumber);
    	try {
			open.start(new Stage());
		} catch (Exception e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
    	}
    }



}

    /*private void initFriendlist() {
		for(int i = 0; i < friends.size(); i++) {
			str.add(friends.get(i));
		}
		lv.setItems(null);
		lv.setItems(str);
	}*/


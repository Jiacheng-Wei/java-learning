package mainMenu;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.Socket;
import java.util.ArrayList;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.image.Image;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import tools.Instruction;

public class ChangePassword extends Application{
	private Pane pane=new Pane();
	private Button confirm=new Button("ȷ��");
	private Button cancel=new Button("ȡ��");
	private PasswordField beforePassword=new PasswordField();
	private PasswordField afterPassword=new PasswordField();
	private Label tip1=new Label("��ǰ����:");
	private Label tip2=new Label("���ĺ������:");
	private Label tip3=new Label("");
	private Socket socket;
	private DatagramSocket sendSocket;
	private DatagramSocket receSocket;
	private String OOnumber;
	
	public ChangePassword() {
		super();
	}
	
	public ChangePassword(String oo,Socket s,DatagramSocket ds,DatagramSocket dr) {
		this.OOnumber=oo;
		this.socket=s;
		this.sendSocket=ds;
		this.receSocket=dr;
	}
	
	public static void main(String args[]) {
		ChangePassword.launch(args);
	}
	@Override
	public void start(Stage primaryStage) throws Exception {
		tip1.setLayoutX(67);
		tip1.setLayoutY(70);
		tip2.setLayoutX(40);
		tip2.setLayoutY(140);
		tip3.setLayoutX(210);
		tip3.setLayoutY(175);
		beforePassword.setLayoutX(150);
		beforePassword.setLayoutY(70);
		afterPassword.setLayoutX(150);
		afterPassword.setLayoutY(140);
		confirm.setLayoutX(160);
		confirm.setLayoutY(200);
		cancel.setLayoutX(260);
		cancel.setLayoutY(200);

		pane.getChildren().addAll(confirm,cancel,beforePassword,afterPassword,tip1,tip2,tip3);
		pane.setStyle("-fx-background-image: url(\"/images/bg2.png\");");
		Scene scene=new Scene(pane,400,300);
		primaryStage.getIcons().add(new Image("/images/password.png"));
		primaryStage.setScene(scene);
		primaryStage.setTitle("�޸�����");
		primaryStage.show();
		
		cancel.setOnAction(e->{primaryStage.close();});
		confirm.setOnAction(e->{
			try {
				go();
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		});
		
	}
    public void go() throws IOException {
    	Instruction ins=new Instruction("2","4",socket.getLocalAddress().toString(),this.OOnumber,"2");
    	ins.addParemeter(beforePassword.getText());
    	ins.addParemeter(afterPassword.getText());
    	ins.send(sendSocket);
    	String react=new String();
    	while(true){
			byte[] buf=new byte[1024];
        	DatagramPacket dp=new DatagramPacket(buf,buf.length);
        	try {
				receSocket.receive(dp);
			} catch (IOException e) {
				e.printStackTrace();
			}
        	react=new String(dp.getData(),0,dp.getLength());
        	break;
		}
    	if(react.equals("1")) {
    		tip3.setText("�޸ĳɹ�!");
    	}
    	else {
    		tip3.setText("�������!");
    	}
    }
}

package login;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.ArrayList;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import mainMenu.MainInterface;
import register.RegisterView;
import register.SuccessRegister;
import tools.Instruction;
import tools.Message;
import users.UserInfo;

public class login extends Application{
    private Pane pane;
    private Label Laccount=new Label("�˺�: ");
    private Label Lpassword=new Label("����:");
    private TextField TXaccount=new TextField();
    private PasswordField TXpassword=new PasswordField();
    private Button Blogin=new Button("��¼");
    private Button register=new Button("ע���˺�");
    private Button forget=new Button("��������");
    private Label tip=new Label("");
    private ComboBox<String> status=new ComboBox<>();

	@Override
	public void start(Stage primaryStage) throws Exception {
		//Ԥ����
		pane=new Pane();
		status.getItems().addAll("����","����","�뿪","æµ");
		status.setValue("����");
		//����
		TXaccount.setLayoutX(80);
		TXaccount.setLayoutY(60);
		TXpassword.setLayoutX(80);
		TXpassword.setLayoutY(100);
		Laccount.setLayoutX(40);
		Laccount.setLayoutY(60);
		Lpassword.setLayoutX(40);
		Lpassword.setLayoutY(100);
		Blogin.setLayoutX(240);
		Blogin.setLayoutY(160);
		status.setLayoutX(100);
		status.setLayoutY(160);
		register.setLayoutX(310);
		register.setLayoutY(60);
		forget.setLayoutX(310);
		forget.setLayoutY(100);
		tip.setLayoutX(120);
		tip.setLayoutY(133);
		//����
		register.setOnAction(e->registerAction());
		Blogin.setOnAction(e->{
			try {
				loginAction(primaryStage);
			} catch (UnknownHostException e1) {
				e1.printStackTrace();
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		});
		
		//����
		pane.getChildren().addAll(Laccount,Lpassword,TXaccount,TXpassword,Blogin,status,register,forget,tip);
		Scene scene=new Scene(pane,400,240);
		primaryStage.setTitle("OICO");
		primaryStage.setScene(scene);
		primaryStage.show();
		pane.setStyle("-fx-background-image: url(\"/images/loginbg.jpg\");");
		primaryStage.getIcons().add(new Image("/images/login.png"));
		
		
		
	}
    public static void main(String args[]) {
    	login.launch(args);
    }
    public void registerAction() {      //����ע�ᰴť�¼����������ʾע�����
    	RegisterView open=new RegisterView();
    	try {
			open.start(new Stage());
		} catch (Exception e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
    }
    public void loginAction(Stage stage) throws UnknownHostException, IOException {
    	Socket socket=new Socket("192.168.1.16",8000);//���ӷ�����
    	DatagramSocket dsocketSend=new DatagramSocket(10000);
    	DatagramSocket dsocketRece=new DatagramSocket(10001);
    	//��������
    	if(TXaccount.getText().trim().equals("")||TXpassword.getText().trim().equals("")) {
    		tip.setText("�������˺�������ٵ�¼");
    		socket.close();
        	dsocketSend.close();
        	dsocketRece.close();
    	}
    	else {	
    	//����������͵�¼�û���Ϣ
        Instruction loginInstruction=new Instruction("1","2",socket.getLocalAddress().toString(),TXaccount.getText(),"1");
        loginInstruction.addParemeter(TXpassword.getText());
    	byte[] loginMessage=loginInstruction.toString().getBytes();
    	DatagramPacket sendPack=new DatagramPacket(loginMessage,loginMessage.length,InetAddress.getByName("192.168.1.16"),10003);
    	dsocketSend.send(sendPack);
    	//���շ��������ص���Ϣ
    	while(true)
		{
			byte[] buf=new byte[4096];
        	DatagramPacket dp=new DatagramPacket(buf,buf.length);
        	try {
				dsocketRece.receive(dp);
			} catch (IOException e) {
				e.printStackTrace();
			}
        	String text=new String(dp.getData(),0,dp.getLength());
        	ArrayList<String> friendlist=new ArrayList<>();
        	ArrayList<Message> disonlineMessage=new ArrayList<>();

        	int i=0;
        	socket.close();
        	dsocketSend.close();
        	dsocketRece.close();
        	if(!text.equals("0")){
            	Instruction backins=Instruction.toInstruction(text);
            	ArrayList<String> para=backins.getParameterList();
            	
            	int friendnum=Integer.valueOf(backins.getSubInstruction());
            	int messagenum=Integer.valueOf(backins.getParmNum());
            	for(;i<friendnum;i++) {
            		friendlist.add(para.get(i));
            	}
            	for(;i<messagenum-1;i++) {
            		disonlineMessage.add(Message.toMessage(para.get(i)));
            	}
            	
        		stage.close();
        		MainInterface open=new MainInterface(TXaccount.getText().trim(),friendlist,disonlineMessage,para.get(i));
        		try {
					open.start(new Stage());
				} catch (Exception e) {
					e.printStackTrace();
				}
        	}
        	else if(text.equals("0")) {
        		tip.setText("�������!");
        		TXpassword.clear();
        	}
        	break;
		}
    	}
    }

}

package tools;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import tools.Message;

public class Message {
    private int fromID;  //������ID
    private int toID;   //������ID
    private String content;  //��Ϣ����
    private int status;   //��Ϣ״̬
    private Date sendtime;  //����ʱ��
    private int id;  //��Ϣ���
    
    public Message() {
    	;
    }

    public Message(int fid,int tid,String c,int s) {
    	fromID = fid;
    	toID = tid;
    	content = c;
    	status = s;
    	sendtime = new Date();
    }

    
    public int getfromID() {
    	return fromID;
    }
    
    public int gettoID() {
    	return toID;
    }
    
    public String getContent() {
    	return content;
    }
    
    public int getStatus() {
    	return status;
    }
    
    public int getID() {
    	return id;
    }
    
    public String getDate() {
    	SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    	String dateStr = format.format(sendtime);
    	return dateStr;
    }
    
    public void setfromID(int fid) {
    	fromID = fid;
    }
    
    public void settoID(int tid) {
    	toID = tid;
    }
    
    public void setID(int id) {
    	this.id = id;
    }
    
    public void setContent(String c) {
    	content = c;
    }
    
    public void setStatus(int s) {
    	status = s;
    }

    public void setDate(String str) {
    	SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    	try {
    		sendtime = format.parse(str);
    	}catch(ParseException e) {
    		e.printStackTrace();
    	}
    }
    public String toString() {
    	return this.fromID+"$"+this.toID+"$"+this.content+"$"+this.status+"$"+this.getDate()+"$";
    }
    public static Message toMessage(String s) {
		int fid = 0;
		int tid = 0;
		String con = null;
		int sta = 0;
		int before=0;
		String theDate=null;

		int after=s.indexOf('$');
		fid=Integer.valueOf(s.substring(before, after));
		before=after+1;
		after=s.indexOf('$',after+1);
		tid=Integer.valueOf(s.substring(before, after));
		before=after+1;
		after=s.indexOf('$',after+1);
		con=s.substring(before,after);
		before=after+1;
		after=s.indexOf('$',after+1);
		sta=Integer.valueOf(s.substring(before, after));
		before=after+1;
		after=s.indexOf('$',after+1);
		theDate=s.substring(before, after);
		
		Message e=new Message(fid,tid,con,sta);
		e.setDate(theDate);
       return e;
	}


}

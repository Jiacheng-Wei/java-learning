package tools;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class Instruction {

	private String mainInstructionType;//ָ���������
	private String subInstructionType;//ָ��Ĵ�����
	private String createTime;//ָ���ʱ��
	private String ipAdress;//������IP
	private String OOnumber;//������OO��
	private String parmNum;
	private ArrayList<String> parameter=new ArrayList<>();//ָ������Ĳ���

	public static void main(String args[]) throws UnknownHostException, IOException {
		String test="�ҽ���Ь(609258667)";
		System.out.println(getOOnumberFromNick(test));
	}
	public Instruction() {
		super();
	}
	public Instruction(String m,String s,String ip,String parmnum) {
		this.mainInstructionType=m;
		this.subInstructionType=s;
		this.ipAdress=ip;
		this.parmNum=parmnum;
    	SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		this.createTime=format.format(new Date());
	}
	public Instruction(String m,String s,String ip,String OO,String parmnum) {
		this.mainInstructionType=m;
		this.subInstructionType=s;
		this.ipAdress=ip;
		this.OOnumber=OO;
		this.parmNum=parmnum;
    	SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		this.createTime=format.format(new Date());
	}
	public Instruction(String m,String s,String ip,String OO,String date,String parmnum) {
		this.mainInstructionType=m;
		this.subInstructionType=s;
		this.ipAdress=ip;
		this.OOnumber=OO;
		this.createTime=date;
		this.parmNum=parmnum;
	}
	public static Instruction toInstruction(String s) {
		String mainInstruction;
		String subInstrucition;
		String Date;
		String IP;
		String OOnumber;
		String parmNum;
		
		int before=0;
		int after=s.indexOf('#');
		mainInstruction=s.substring(before, after);
		before=after+1;
		after=s.indexOf('#',after+1);
		subInstrucition=s.substring(before,after);
		before=after+1;
		after=s.indexOf('#',after+1);
		Date=s.substring(before,after);
		before=after+1;
		after=s.indexOf('#',after+1);
		IP=s.substring(before,after);
		before=after+1;
		after=s.indexOf('#',after+1);
		OOnumber=s.substring(before,after);
		before=after+1;
		after=s.indexOf('#',after+1);
		parmNum=s.substring(before,after);
		
		Instruction e=new Instruction(mainInstruction,subInstrucition,IP,OOnumber,Date,parmNum);
	
       for(int i=0;i<Integer.valueOf(parmNum).intValue();i++) {
    		before=after+1;
    		after=s.indexOf('#',after+1);
    		e.addParemeter(s.substring(before,after));
		}
       return e;
	}
	public String toString() {
		return this.getMainInstruction()+"#"+this.getSubInstruction()+"#"+this.getDate()+"#"+this.getIp()
		+"#"+this.getOOnumber()+"#"+this.getParmNum()+"#"+this.getParameter();
	}
	public void send(DatagramSocket ds) throws IOException {
        byte[] message=this.toString().getBytes();
        DatagramPacket sendPack=new DatagramPacket(message,message.length,InetAddress.getByName("192.168.1.16"),10003);
        ds.send(sendPack);
	}
	public void addParemeter(String parm) {
		this.parameter.add(parm);
	}
	
	public String getMainInstruction( ) {
		return this.mainInstructionType;
	}
	
	public String getSubInstruction( ) {
		return this.subInstructionType;
	}
	
	public String getDate( ) {
		return this.createTime;
	}
	
	public String getIp( ) {
		return this.ipAdress;
	}
	public String getTrueIp( ) {
		return this.ipAdress.substring(1);
	}
	public String getOOnumber( ) {
		return this.OOnumber;
	}
	
	public String getParmNum( ) {
		return this.parmNum;
	}
	public String getParameter( ) {
		String s=new String();

		for(int i=0;i<this.parameter.size();i++) {
			s=s+this.parameter.get(i)+"#";
		}
		return s;
	}
	public ArrayList<String> getParameterList( ) {

		return this.parameter;
	}
	public void setParmNum(int number) {
		Integer num=new Integer(number);
		this.parmNum=num.toString();
	}

	///////////////////////////////////////
    public static String getOOnumberFromNick(String s) {
    	return s.substring(s.indexOf('(')+1,s.length()-1);
    }
}

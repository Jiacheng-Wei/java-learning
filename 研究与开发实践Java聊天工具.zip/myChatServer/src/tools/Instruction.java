package tools;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class Instruction {

	private String mainInstructionType;//ָ���������
	private String subInstructionType;//ָ��Ĵ�����
	private String createTime;//ָ���ʱ��
	private String ipAdress;//������IP
	private String OOnumber;//������OO��
	private String parmNum;

	private ArrayList<String> parameter=new ArrayList<>();//ָ������Ĳ���

	public Instruction() {
		super();
	}
	public Instruction(String m,String s,String ip,String parmnum) {
		this.mainInstructionType=m;
		this.subInstructionType=s;
		this.ipAdress=ip;
		this.parmNum=parmnum;
    	SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		this.createTime=format.format(new Date());
	}
	public Instruction(String m,String s,String ip,String OO,String parmnum) {
		this.mainInstructionType=m;
		this.subInstructionType=s;
		this.ipAdress=ip;
		this.OOnumber=OO;
		this.parmNum=parmnum;
    	SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		this.createTime=format.format(new Date());
	}
	public Instruction(String m,String s,String ip,String OO,String date,String parmnum) {
		this.mainInstructionType=m;
		this.subInstructionType=s;
		this.ipAdress=ip;
		this.OOnumber=OO;
		this.createTime=date;
		this.parmNum=parmnum;
	}
	public static Instruction toInstruction(String s) {
		String mainInstruction;
		String subInstrucition;
		String Date;
		String IP;
		String OOnumber;
		String parmNum;
		if(s.indexOf('#')!=-1) {
		int before=0;
		int after=s.indexOf('#');
		mainInstruction=s.substring(before, after);
		before=after+1;
		after=s.indexOf('#',after+1);
		subInstrucition=s.substring(before,after);
		before=after+1;
		after=s.indexOf('#',after+1);
		Date=s.substring(before,after);
		before=after+1;
		after=s.indexOf('#',after+1);
		IP=s.substring(before,after);
		before=after+1;
		after=s.indexOf('#',after+1);
		OOnumber=s.substring(before,after);
		before=after+1;
		after=s.indexOf('#',after+1);
		parmNum=s.substring(before,after);
		
		Instruction e=new Instruction(mainInstruction,subInstrucition,IP,OOnumber,Date,parmNum);
	
       for(int i=0;i<Integer.valueOf(parmNum).intValue();i++) {
    		before=after+1;
    		after=s.indexOf('#',after+1);
    		e.addParemeter(s.substring(before,after));
		}
       return e;
       }
		return null;
	}
	public String toString() {
		return this.getMainInstruction()+"#"+this.getSubInstruction()+"#"+this.getDate()+"#"+this.getIp()
		+"#"+this.getOOnumber()+"#"+this.getParmNum()+"#"+this.getParameter();
	}
	//���Ӳ���
	public void addParemeter(String parm) {
		this.parameter.add(parm);
	}
	//get����
	public String getMainInstruction( ) {
		return this.mainInstructionType;
	}
	
	public String getSubInstruction( ) {
		return this.subInstructionType;
	}
	
	public String getDate( ) {
		return this.createTime;
	}
	
	public String getIp( ) {
		return this.ipAdress;
	}
	public String getTrueIp( ) {
		return this.ipAdress.substring(1);
	}
	public String getOOnumber( ) {
		return this.OOnumber;
	}
	
	public String getParmNum( ) {
		return this.parmNum;
	}
	//��ò����ַ���
	public String getParameter( ) {
		String s=new String();

		for(int i=0;i<this.parameter.size();i++) {
			s=s+this.parameter.get(i)+"#";
		}
		return s;
	}
	//��ò�����
	public ArrayList<String> getParameterList( ) {

		return this.parameter;
	}
	
	//set����
	public void setParameter(ArrayList<Integer> e) {

		for(int i=0;i<e.size();i++) {
			this.parameter.add(e.get(i).toString());
		}
	}
	public void setParmNum(int number) {
		Integer num=new Integer(number);
		this.parmNum=num.toString();
	}
	public void setSubIns(int number) {
		Integer num=new Integer(number);
		this.subInstructionType=num.toString();
	}

	///////////////////////////////////////
    public static String getOOnumberFromNick(String s) {
    	return s.substring(s.indexOf('(')+1,s.length()-1);
    }
}

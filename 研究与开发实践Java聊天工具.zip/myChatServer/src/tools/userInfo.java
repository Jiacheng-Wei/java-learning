package tools;

import java.util.ArrayList;

public class userInfo {
private String ip;
private String OOnumber;
public userInfo(String ip,String oo) {
	this.ip=ip;
	this.OOnumber=oo;
}

public static String getIp(ArrayList<userInfo> e,String oo) {
	String returnip=new String();
	for(int i=0;i<e.size();i++) {
		if(e.get(i).getOO().equals(oo))
			returnip=e.get(i).getIp();
	}
	return returnip;
}
public static int getIndex(ArrayList<userInfo> e,String oo) {
	int k=0;
	for(int i=0;i<e.size();i++) {
		if(e.get(i).getOO().equals(oo))
			k=i;
	}
	return k;
}
public String getOO() {
	return this.OOnumber;
}
public String getIp() {
	return this.ip;
}
}

package database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class ApplyFriendDB {
    
    public static void main(String args[]) {
    	ApplyFriendDB conn=new ApplyFriendDB();
   	 
    }
		private Connection conn = null;
	    private Statement stmt = null;
	    private ResultSet rs = null;
	    
	    public ApplyFriendDB(){
	   	    ;
	    }
	    
	    public Connection getConnection() {
	        try {
	       	 Class.forName("com.mysql.jdbc.Driver");
	       	 conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/oico_database?useSSL=true&useUnicode=true&characterEncoding=utf-8", "root", "guandao1");

	        }
	        catch(Exception ex) {
	       	 ex.printStackTrace();
	        }
	        return conn;
	    }
	    
	    public void close() {
	      	 try {
	      		 if(rs!=null)
	      		 rs.close();
	      		 if(stmt!=null)
	      		 stmt.close();
	      		 if(conn!=null)
	      		 conn.close();
	      	 }
	      	 catch(Exception ex) {
	      		 ex.printStackTrace();
	      	 }
	    }
	    
	    public ArrayList<Integer> getUnreadApply(int id){  //��ȡδ����������
	    	ArrayList<Integer> list = new ArrayList<>();
	    	String tid = new Integer(id).toString();
	    	try {
	    		conn = getConnection();
	    		stmt = conn.createStatement();
	    		String sql = "select fromID from tb_applyfriend where toID = '"+tid+"' and status = 0";
	    		rs = stmt.executeQuery(sql);
	    		while(rs.next()) {
	    			list.add(new Integer(rs.getInt("fromID")));
	    		}
	    		close();
	    	}
	    	catch(SQLException ex) {
	    		ex.printStackTrace();
	    	}
	    	return list;
	    }
	    public int Insert(int fid,int tid) {  //����һ������
	    	int result = 0;
	    	String id1 = new Integer(tid).toString();
	    	String id2 = new Integer(fid).toString();
	    	try {
	    		conn = getConnection();
	    		stmt = conn.createStatement();
	    		String sql = "insert into tb_applyfriend (fromID,toID,status)"
	    				+"values ('"+id2+"','"+id1+"','1')";
	    		result = stmt.executeUpdate(sql);
	    		close();
	    	}
	    	catch(SQLException ex) {
	    		ex.printStackTrace();
	    		result = 0;
	    	}
	    	return result;
	    }
	    public int Delete(int fid,int tid) {  //ɾ��һ������
	    	int result = 0;
	    	String id1 = new Integer(tid).toString();
	    	String id2 = new Integer(fid).toString();
	    	try {
	    		conn = getConnection();
	    		stmt = conn.createStatement();
	    		String sql = "delete from tb_applyfriend where fromID = '"+id2+"' and toID = '"+id1+"'";
	    		result = stmt.executeUpdate(sql);
	    		close();
	    	}
	    	catch(SQLException ex) {
	    		ex.printStackTrace();
	    		result = 0;
	    	}
	    	return result;
	    }
	    
	    public int updateStatus1(int fid,int tid) {  //��״̬����Ϊ1��ͬ������
	    	int result = 0;
	    	String id1 = new Integer(tid).toString();
	    	String id2 = new Integer(fid).toString();
	    	try {
	    		conn = getConnection();
	    		stmt = conn.createStatement();
	    		String sql = "update tb_applyfriend set status = 1 where fromID = '"+id2+"' and toID = '"+id1+"'";
	    		result = stmt.executeUpdate(sql);
	    		close();
	    	}
	    	catch(SQLException ex) {
	    		ex.printStackTrace();
	    		result = 0;
	    	}
	    	return result;
	    }
	    
	    public int updateStatus2(int fid,int tid) {  //��״̬����Ϊ2���ܾ�����
	    	int result = 0;
	    	String id1 = new Integer(tid).toString();
	    	String id2 = new Integer(fid).toString();
	    	try {
	    		conn = getConnection();
	    		stmt = conn.createStatement();
	    		String sql = "update tb_applyfriend set status = 2 where fromID = '"+id2+"' and toID = '"+id1+"'";
	    		result = stmt.executeUpdate(sql);
	    		close();
	    	}
	    	catch(SQLException ex) {
	    		ex.printStackTrace();
	    		result = 0;
	    	}
	    	return result;
	    }
}

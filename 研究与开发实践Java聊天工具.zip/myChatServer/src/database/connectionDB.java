package database;

import java.sql.*;

public class connectionDB {
     private Connection conn = null;
     private Statement stmt = null;
     private ResultSet rs = null;
     
     
     public static void main(String args[]) {
    	 connectionDB conn=new connectionDB();
         System.out.println(conn.getNowOOnumber());
         System.out.println(conn.getBirthday(100000));
         conn.updateBirthday(100000, 5);
    	 
     }
     public connectionDB(){
    	 ;
     }
     
     public Connection getConnection() {
         try {
        	 Class.forName("com.mysql.jdbc.Driver");
        	 conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/oico_database?useSSL=true&useUnicode=true&characterEncoding=utf-8", "root", "guandao1");
         }
         catch(Exception ex) {
        	 ex.printStackTrace();
         }
         return conn;
     }
     
     public void close() {
    	 try {
    		 if(rs!=null)
    		 rs.close();
    		 if(stmt!=null)
    		 stmt.close();
    		 if(conn!=null)
    		 conn.close();
    	 }
    	 catch(Exception ex) {
    		 ex.printStackTrace();
    	 }
     }
     
     /*public ResultSet executeQuery(String sql) {
    	 try {
    		 conn = getConnection();
    		 stmt = conn.createStatement();
    		 rs = stmt.executeQuery(sql);
    	 }
    	 catch(SQLException ex) {
    		 ex.printStackTrace();
    	 }
    	 return rs;
     }
     
     public int executeUpdate(String sql) {
    	 int result = 0;
    	 try {
    		 conn = getConnection();
    		 stmt = conn.createStatement();
    		 result = stmt.executeUpdate(sql);
    	 }
    	 catch(SQLException ex) {
    		 result = 0;
    		 System.out.println("更新失败！");
    	 }
    	 return result;
     }*/
     

     
     public String getNickname(int OOnumber) {
    	 String nkname = "";
    	 try {
    		 conn = getConnection();
    		 stmt = conn.createStatement();
        	 String sql = "select nickname from tb_user where id = '"+OOnumber+"'";
        	 rs = stmt.executeQuery(sql);
    		 if(rs.next()){
        	 nkname = rs.getString("nickname");
        	 conn.close();
    		 }
    	 }
    	 catch(SQLException ex) {
    		 ex.printStackTrace();
    		 nkname="";
    	 }
    	 return nkname;
     }
     
     public String getSex(int OOnumber) {
    	 String s = null;
    	 try {
    		 conn = getConnection();
    		 stmt = conn.createStatement();
    		 String sql = "select sex from tb_user where id = '"+OOnumber+"'";
    		 rs = stmt.executeQuery(sql);
    		 if(rs.next()){
    		 s = rs.getString("sex");
        	 conn.close();
    		 }
    	 }
    	 catch(SQLException ex) {
    		 ex.printStackTrace();
    	 }
    	 return s;
     }
     
     public Integer getBirthyear(int OOnumber) {
    	 int by = 0;
    	 try {
    		 conn = getConnection();
    		 stmt = conn.createStatement();
    		 String sql = "select birthyear from tb_user where id = '"+OOnumber+"'";
    		 rs = stmt.executeQuery(sql);
    		 if(rs.next()){
    		 by = rs.getInt(1);
        	 conn.close();
    		 }
    	 }
    	 catch(SQLException ex) {
    		 ex.printStackTrace();
    	 }
    	 return by;
     }  
     
     public Integer getBirthmonth(int OOnumber) {
    	 int bm = 0;
    	 try {
    		 conn = getConnection();
    		 stmt = conn.createStatement();
    		 String sql = "select birthmonth from tb_user where id = '"+OOnumber+"'";
    		 rs = stmt.executeQuery(sql);
    		 if(rs.next()){
    		 bm = rs.getInt(1);
        	 conn.close();
    		 }
    	 }
    	 catch(SQLException ex) {
    		 ex.printStackTrace();
    	 }
    	 return bm;
     }
     
     public Integer getBirthday(int OOnumber) {
    	 int bd = 0;
    	 try {
    		 conn = getConnection();
    		 stmt = conn.createStatement();
    		 String sql = "select birthday from tb_user where id = '"+OOnumber+"'";
    		 rs = stmt.executeQuery(sql);
    		 if(rs.next()){
    		 bd = rs.getInt(1);
        	 conn.close();
    		 }
    	 }
    	 catch(SQLException ex) {
    		 ex.printStackTrace();
    	 }
    	 return bd;
     }
     public String getStatus(int OOnumber) { 
    	 String status = null;
    	 try {
    		 conn = getConnection();
    		 stmt = conn.createStatement();
    		 String sql = "select status from tb_user where id = '"+OOnumber+"'";
    		 rs = stmt.executeQuery(sql);
    		 if(rs.next()){
    		 status = rs.getString(1);
        	 conn.close();
    		 }
    	 }
    	 catch(SQLException ex) {
    		 ex.printStackTrace();
    	 }
    	 return status;
     }
     public String getNowOOnumber() {  
    	 String s = new String("");
    	 int result;
    	 try {
    		 conn = getConnection();
    		 stmt = conn.createStatement();
    		 String sql = "select now from nowoonumber";
    		 rs = stmt.executeQuery(sql);
    		 if(rs.next()){
       		 s = rs.getString("now");
       		 }
    		 Integer k=Integer.valueOf(s)+1;
    		 String h=k.toString();
    		 sql = "update nowoonumber set now = '"+k+"'";
    		 result = stmt.executeUpdate(sql);
        	 conn.close();
        	 }
    	 catch(SQLException ex) {
    		 ex.printStackTrace();
    	 }
    	 return s;
     }
     public String getPassword(int OOnumber) {
    	 String pw = null;
    	 try {
    		 conn = getConnection();
    		 stmt = conn.createStatement();
    		 String sql = "select password from tb_user where id = '"+OOnumber+"'";
    		 rs = stmt.executeQuery(sql);
    		 if(rs.next()){
    		 pw = rs.getString("password");
        	 conn.close();
    		 }
    	 }
    	 catch(SQLException ex) {
    		 ex.printStackTrace();
    	 }
    	 return pw;
     }
     
     public int Insert(int OOnumber,String nkname,String sex,int by,int bm,int bd,String pw,String sta) { //插入一条用户记录
    	 int result = 0;
    	 try {
    		 conn = getConnection();
    		 stmt = conn.createStatement();
    		 String sql = "insert into tb_user (id,nickname,sex,birthyear,birthmonth,birthday,password,status)"+
    			        "values ('"+OOnumber+"','"+nkname+"','"+sex+"','"+by+"','"+bm+"','"+bd+"','"+pw+"','"+sta+"')";
    		 result = stmt.executeUpdate(sql);
        	 conn.close();
    	 }
    	 catch(Exception ex) {
    		 ex.printStackTrace();
    		 result = 0;
    	 }
    	 return result;
     }
     
     public int Delete(int OOnumber) {  //删除一条用户记录
    	 int result = 0;
    	 try {
    		 conn = getConnection();
    		 stmt = conn.createStatement();
    		 String sql = "delete from tb_user where id = '"+OOnumber+"'";
    		 result = stmt.executeUpdate(sql);
        	 conn.close();
    	 }
    	 catch(Exception ex) {
    		 ex.printStackTrace();
    		 result = 0;
    	 }
    	 return result;
     }
     
     public int updateNickname(int OOnumber,String nkname) {  //修改昵称
    	 int r = 0;
    	 try {
    		 conn = getConnection();
    		 stmt = conn.createStatement();
    		 String sql = "update tb_user set nickname = '"+nkname+"' where id = '"+OOnumber+"'";
    		 r = stmt.executeUpdate(sql);
        	 conn.close();
    	 }
    	 catch(Exception ex) {
    		 ex.printStackTrace();
    		 r = 0;
    	 }
    	 return r;
     }
     
     public int updateSex(int OOnumber,String s) {  //修改性别
    	 int result = 0;
    	 try {
    		 conn = getConnection();
    		 stmt = conn.createStatement();
    		 String sql = "update tb_user set sex = '"+s+"' where id = '"+OOnumber+"'";
    		 result = stmt.executeUpdate(sql);
        	 conn.close();
    	 }
    	 catch(Exception ex) {
    		 ex.printStackTrace();
    		 result = 0;
    	 }
    	 return result;
     }
     
     public int updateBirthyear(int OOnumber,int by) {  //修改出生年份
    	 int result = 0;
    	 try {
    		 conn = getConnection();
    		 stmt = conn.createStatement();
    		 String sql = "update tb_user set birthyear = '"+by+"' where id = '"+OOnumber+"'";
    		 result = stmt.executeUpdate(sql);
        	 conn.close();
    	 }
    	 catch(Exception ex) {
    		 ex.printStackTrace();
    		 result = 0;
    	 }
    	 return result;
     }
     
     public int updateBirthmonth(int OOnumber,int bm) {  //修改出生月份
    	 int result = 0;
    	 try {
    		 conn = getConnection();
    		 stmt = conn.createStatement();
    		 String sql = "update tb_user set birthmonth = '"+bm+"' where id = '"+OOnumber+"'";
    		 result = stmt.executeUpdate(sql);
        	 conn.close();
    	 }
    	 catch(Exception ex) {
    		 ex.printStackTrace();
    		 result = 0;
    	 }
    	 return result;
     }
     
     public int updateBirthday(int OOnumber,int bd) {  //修改出生日期
    	 int result = 0;
    	 try {
    		 conn = getConnection();
    		 stmt = conn.createStatement();
    		 String sql = "update tb_user set birthday = '"+bd+"' where id = '"+OOnumber+"'";
    		 result = stmt.executeUpdate(sql);
        	 conn.close();
    	 }
    	 catch(Exception ex) {
    		 ex.printStackTrace();
    		 result = 0;
    	 }
    	 return result;
     }
     
     public int updatePW(int OOnumber,String pw) {  //修改密码
    	 int result = 0;
    	 try {
    		 conn = getConnection();
    		 stmt = conn.createStatement();
    		 String sql = "update tb_user set password = '"+pw+"' where id = '"+OOnumber+"'";
		     result = stmt.executeUpdate(sql);
        	 conn.close();
    	 }
    	 catch(Exception ex) {
    		 ex.printStackTrace();
    		 result = 0;
    	 }
    	 return result;
     }
     
     public int updateStatus(int OOnumber,String sta) {  //修改密码
    	 int result = 0;
    	 try {
    		 conn = getConnection();
    		 stmt = conn.createStatement();
    		 String sql = "update tb_user set status = '"+sta+"' where id = '"+OOnumber+"'";
		     result = stmt.executeUpdate(sql);
        	 conn.close();
    	 }
    	 catch(Exception ex) {
    		 ex.printStackTrace();
    		 result = 0;
    	 }
    	 return result;
     }
}






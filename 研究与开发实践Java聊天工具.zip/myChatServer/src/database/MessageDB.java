package database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

import database.Message;

public class MessageDB {
	private Connection conn = null;
    private Statement stmt = null;
    private ResultSet rs = null;
    
    public static void main(String args[]) {
    	MessageDB mconn=new MessageDB();
    	ArrayList<Message> k=mconn.getHistoricalMessages(100003,100002);
    	ArrayList<Message> d=mconn.getHistoricalMessages(100002,100003);
    	k.addAll(d);
    	for(int i=0;i<k.size();i++) {
    		System.out.println(k.get(i).toString());
    	}
    }
    public MessageDB(){
   	 ;
    }
    
    public Connection getConnection() {
        try {
       	 Class.forName("com.mysql.jdbc.Driver");
       	 conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/oico_database?useSSL=true&useUnicode=true&characterEncoding=utf-8", "root", "guandao1");

        }
        catch(Exception ex) {
       	 ex.printStackTrace();
        }
        return conn;
    }
    
    public void close() {
   	 try {
   		 if(rs!=null)
   		 rs.close();
   		 if(stmt!=null)
   		 stmt.close();
   		 if(conn!=null)
   		 conn.close();
   	 }
   	 catch(Exception ex) {
   		 ex.printStackTrace();
   	 }
    }
   	 
   	 public int createNewTable(int id) {  //Ϊ��ע���û����������¼��
   		 int result = 0;
   		 String uid = new Integer(id).toString();
   		 try {
   			 conn = getConnection();
   			 stmt = conn.createStatement();
   			 String sql = "create table tb_"+uid+"("
   			 +"id int auto_increment primary key not null,"
   			 +"fromID int,"
   			 +"toID int,"
   			 +"message text,"
   			 +"status int,"
   			 +"sendtime datetime)charset utf8 collate utf8_general_ci";
   			 result = stmt.executeUpdate(sql);
   			 if(result!=0) {
   				 System.out.println("�����ɹ���");
   			 }
   			 close();
   		 }
   		 catch(SQLException ex) {
   			 ex.printStackTrace();
   			 result = 0;
   		 }
   		 return result;
   	 }
     
   	 public int AddMessage(Message m) {  //����в���һ����Ϣ
   		 int result = 0;
   		 int fid = m.getfromID();
   		 int tid = m.gettoID();
   		 String id = new Integer(tid).toString();
   		 String c = m.getContent();
   		 int status = m.getStatus();
   		 String dateStr = m.getDate();
   		 try {
   			 conn = getConnection();
   			 stmt = conn.createStatement();
   			 String sql = "insert into tb_"+id +"(fromID,toID,message,status,sendtime)"
   			 +"values('"+fid+"','"+tid+"','"+c+"','"+status+"','"+dateStr+"')";
   			 result = stmt.executeUpdate(sql,Statement.RETURN_GENERATED_KEYS);
   			 rs = stmt.getGeneratedKeys();
             if(rs.next()) {
       			 m.setID(rs.getInt(1));
             }
   			 if(result!=0) {
   				 System.out.println("��Ϣ����ɹ���");
   			 }
   			 //String sql2 = "select max(id) from tb_"+id;
   			 close();
   		 }
   		 catch(SQLException ex) {
   			 ex.printStackTrace();
   			 result = 0;
   		 }
   		 return result;
   	 }
   	 
   	 public ArrayList<Message> getUnreadMessages(int id){  //��ȡδ����Ϣ
   		 ArrayList<Message> list = new ArrayList<>();
   		 String u = new Integer(id).toString();
   		 int fid;
   		 int tid;
   		 String c = null;
   		 int theId;
   		 int s;
   		 String dateStr = null;
   		 try {
   			 conn = getConnection();
   			 stmt = conn.createStatement();
   			 String sql = "select * from tb_"+u+" where status = 0";
   			 rs = stmt.executeQuery(sql);
   			 while(rs.next()) {
   				 fid = rs.getInt("fromID");
   				 tid = rs.getInt("toID");
   				theId=rs.getInt("id");
   				 c = rs.getString("message");
   				 s = rs.getInt("status");
   				 dateStr = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(rs.getTimestamp("sendtime"));
   				 Message m = new Message();
   				 m.setfromID(fid);
   				 m.settoID(tid);
   				 m.setContent(c);
   				 m.setStatus(s);
   				 m.setDate(dateStr);
   				 m.setID(theId);
   				 list.add(m);
   			 }
   			 close();
   		 }
   		 catch(SQLException ex) {
   			 ex.printStackTrace();
   		 }
   		 return list;
   	 }
   	 
   	 public int updateStatus(Message m) {  //������Ϣ״̬
   		 int result = 0;
   		 int uid = m.gettoID();
   		 int id = m.getID();
   		 try {
   			 conn = getConnection();
   			 stmt = conn.createStatement();
   			 String sql = "update tb_"+uid+" set status = '1' where id = '"+id+"'";
   			 result = stmt.executeUpdate(sql);
   		 }
   		 catch(SQLException ex) {
   			 ex.printStackTrace();
   			 result = 0;
   		 }
   		 return result;
   	 }
   	public ArrayList<Message> getHistoricalMessages(int id1,int id2){ //��ȡ�Ѷ���Ϣ
  		 ArrayList<Message> list = new ArrayList<>(); 
  		 String id3 = new Integer(id1).toString();
  		 String id4 = new Integer(id2).toString();
  		 int fid;
  		 int tid;
  		 int s;
  		 String c = null;
  		 String dateStr = null;
  		 try {
  			 conn = getConnection();
  			 stmt = conn.createStatement();
  			 String sql = "select * from tb_"+id3+" where fromID = '"+id4+"' and status = 1 order by sendtime asc";
  			 rs = stmt.executeQuery(sql);
  			 while(rs.next()) {
  				 fid = rs.getInt("fromID");
  				 tid = rs.getInt("toID");
  				 s = rs.getInt("status");
  				 c = rs.getString("message");
  				 dateStr = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(rs.getTimestamp("sendtime"));
  				 Message m = new Message();
 				 m.setfromID(fid);
 				 m.settoID(tid);
 				 m.setContent(c);
 				 m.setStatus(s);
 				 m.setDate(dateStr);
 				 list.add(m);
  			 }
  			 close();
  		 }
  		 catch(SQLException ex) {
  			 ex.printStackTrace();
  		 }
  		 return list;
  	 }
}

package database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class friendDB {
    private Connection conn = null;
    private Statement stmt = null;
    private ResultSet rs = null;
    
    public friendDB(){
   	    ;
    }
    
    public Connection getConnection() {
        try {
       	 Class.forName("com.mysql.jdbc.Driver");
       	 conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/oico_database?useSSL=true&useUnicode=true&characterEncoding=utf-8", "root", "guandao1");

        }
        catch(Exception ex) {
       	 ex.printStackTrace();
        }
        return conn;
    }
    
    public void close() {
   	 try {
   		 if(rs!=null)
   		 rs.close();
   		 if(stmt!=null)
   		 stmt.close();
   		 if(conn!=null)
   		 conn.close();
   	 }
   	 catch(Exception ex) {
   		 ex.printStackTrace();
   	 }
    }
    
    public int AddFriend(int uid1,int uid2) {   //���Ӻ���
    	int result = 0;
    	ArrayList<Integer> list = new ArrayList<>();
    	list = getFriendList(uid1);
    	if(list.contains(new Integer(uid2))) {
    		result = 1;
    		System.out.println("�Ѿ����Ӹ��û�Ϊ���ѣ�");
    	}
    	else {
    	try {
    		conn = getConnection();
    		stmt = conn.createStatement();
    		/*if(uid1>uid2) {
    			int temp = uid1;
    			uid1 = uid2;
    			uid2 = uid1;
    		}*/                                                                                                                                                                                                                                                            
    		String sql = "insert into tb_friend (uid1,uid2)"+
			        "values ('"+uid1+"','"+uid2+"')";
    		result = stmt.executeUpdate(sql);
    		sql = "insert into tb_friend (uid1,uid2)"+
			        "values ('"+uid2+"','"+uid1+"')";
    		result = stmt.executeUpdate(sql);
    		close();
    	}
    	catch(SQLException ex) {
    		ex.printStackTrace();
    		result = 0;
    	}
    	}
    	return result;
    }
    
    public int DeleteFriend(int uid1,int uid2) {  //ɾ������
    	int result = 0;
    	try {
    		conn = getConnection();
    		stmt = conn.createStatement();
    		/*if(uid1>uid2) {
    			int temp = uid1;
    			uid1 = uid2;
    			uid2 = uid1;
    		}*/
    		String sql = "delete from tb_friend where uid1 = '"+uid1+"' and uid2 = '"+uid2+"'";
    		result = stmt.executeUpdate(sql);
    		close();
    	}
    	catch(SQLException ex) {
    		ex.printStackTrace();
    		result = 0;
    	}
    	return result;
    }
    public ArrayList<Integer> getFriendList(int id) {  //��ú����б�
    	ArrayList<Integer> friendlist = new ArrayList<>();
    	try {
    		conn = getConnection();
    		stmt = conn.createStatement();
    		String sql = "select uid2 from tb_friend where uid1 = '"+id+"'";
    		rs = stmt.executeQuery(sql);
    		while(rs.next()) {
    			friendlist.add(new Integer(rs.getInt("uid2")));
    		}
    		close();
    	}
    	catch(SQLException ex) {
    		ex.printStackTrace();
    	}
    	return friendlist;
    }
}

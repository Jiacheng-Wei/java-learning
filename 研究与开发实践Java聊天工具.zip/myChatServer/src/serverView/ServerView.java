package serverView;

import java.io.DataOutputStream;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;

import database.connectionDB;
import database.friendDB;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextArea;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import tools.Instruction;
import database.Message;
import database.MessageDB;
import tools.userInfo;

public class ServerView extends Application{
    private Pane pane=new Pane();
    private TextArea users=new TextArea();
    private TextArea cache=new TextArea();
	private Label oonumber=new Label("OO��"),ip=new Label("IP"),status=new Label("״̬"),mainInfo=new Label("��Ҫ��Ϣ"),
			online=new Label("����");
	private ServerSocket serversocket;
	private connectionDB conn=new connectionDB();
	private friendDB fconn=new friendDB();
	private MessageDB mconn=new MessageDB();
	private ArrayList<userInfo> onlineUser=new ArrayList<>();
	public static void main(String[] args) {
		ServerView.launch(args);

	}

	@Override
	public void start(Stage primaryStage) throws Exception {

		users.setLayoutX(30);
		users.setLayoutY(100);
		cache.setLayoutX(30);
		cache.setLayoutY(500);
		oonumber.setLayoutX(200);
		oonumber.setLayoutY(70);
		ip.setLayoutX(400);
		ip.setLayoutY(70);
		status.setLayoutX(600);
		status.setLayoutY(70);
		mainInfo.setLayoutX(300);
		mainInfo.setLayoutY(480);
		online.setLayoutX(50);
		online.setLayoutY(70);
		
		pane.getChildren().addAll(users,cache,oonumber,ip,status,mainInfo,online);
		Scene scene=new Scene(pane,700,800);

       
        primaryStage.setOnCloseRequest(e->{
        	try {close();} catch (IOException e2) {e2.printStackTrace();}
        	});
		new Thread(() -> listen()).start();
		new Thread(() -> {
			try {
				dealInstruction();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}).start();
		
		
		primaryStage.setTitle("������");
		primaryStage.setScene(scene);
		primaryStage.show();
		
	}
	public void listen() {
		try {
			serversocket=new ServerSocket(8000);
			while(true){
				Socket socket=serversocket.accept();
				new Thread(() ->  {
					
				}).start();
				cache.setText(new Date()+socket.toString()+"����");
			}

		}catch(IOException ex) {
			ex.printStackTrace();
		}
	}
	public void dealInstruction() throws IOException {
	       
			DatagramSocket sendSocket = new  DatagramSocket();
	        DatagramSocket receSocket = new  DatagramSocket(10003);
            ArrayList<String> parameter;
           while (true)
           {
        	byte[] buf=new byte[1024];
           	DatagramPacket dp=new DatagramPacket(buf,buf.length);
           	try {
   				receSocket.receive(dp);
   			} catch (IOException e) {
   				e.printStackTrace();
   			}
           	String text=new String(dp.getData(),0,dp.getLength());
           	Instruction instruction=Instruction.toInstruction(text);
           	parameter=instruction.getParameterList();
           	int receOOnumber=Integer.valueOf(instruction.getOOnumber());
           	
           	switch(instruction.getMainInstruction()){
           	case("1"):switch(instruction.getSubInstruction()) {
           	//����1.1 ע��
           		      case("1"):String OOnumber=conn.getNowOOnumber();
           		      			int intoonumber=Integer.valueOf(OOnumber);
           		      			String status="����";
           		      			mconn.createNewTable(intoonumber);
           		                byte[] registerMessage=OOnumber.getBytes();
           		                DatagramPacket registerPack=new DatagramPacket(registerMessage,registerMessage.length,InetAddress.getByName(instruction.getTrueIp()),10001);
           		                conn.Insert(Integer.valueOf(OOnumber), parameter.get(0), parameter.get(2),
           		                Integer.valueOf(parameter.get(3)), Integer.valueOf(parameter.get(4)), 
           		                Integer.valueOf(parameter.get(5)), parameter.get(1),status);
           		                sendSocket.send(registerPack);
           		                break;
            //����1.2 ��¼
           		      case("2"):int myoo=Integer.valueOf(instruction.getOOnumber());
           		    	  		ArrayList<Integer> friends=fconn.getFriendList(myoo);
           		    	  		ArrayList<Message> disonlineMessage=mconn.getUnreadMessages(myoo);
           		    	  		String reAction=new String();//�����Ƿ���ȷ
           		    	  		//�������
           			            if(!parameter.get(0).equals(conn.getPassword(Integer.valueOf(instruction.getOOnumber())))) {
           			    	    reAction="0";
          			            byte[] loginMessage=reAction.getBytes();
        		                DatagramPacket loginPack=new DatagramPacket(loginMessage,loginMessage.length,InetAddress.getByName(instruction.getTrueIp()),10001);
        		                sendSocket.send(loginPack);
           			            }
           			            //������ȷ
           			            else {
           			            //״̬����Ϊ����
              			    	conn.updateStatus(Integer.valueOf(instruction.getOOnumber()), "����");
              			    	this.onlineUser.add(new userInfo(instruction.getTrueIp(),instruction.getOOnumber()));
              			    	Instruction backins=new Instruction("0","0","192.168.1.16",instruction.getOOnumber(),"0");
              			    	backins.setParmNum(friends.size()+disonlineMessage.size()+1);
              			    	backins.setSubIns(friends.size());
              			    	//��ȡ�����б���δ����Ϣ
              			    	for(int i=0;i<friends.size();i++) {
           			            backins.addParemeter(conn.getNickname(friends.get(i))+"("+friends.get(i).toString()+")");
              			    	}
              			    	for(int i=0;i<disonlineMessage.size();i++) {
               			            backins.addParemeter(disonlineMessage.get(i).toString());
               			            mconn.updateStatus(disonlineMessage.get(i));
                  			    	}
              			    	backins.addParemeter(conn.getNickname(myoo));
              			    	
           			            byte[] loginMessage=backins.toString().getBytes();
        		                DatagramPacket loginPack=new DatagramPacket(loginMessage,loginMessage.length,InetAddress.getByName(instruction.getTrueIp()),10001);
        		                sendSocket.send(loginPack);
           			            }
           			            
           			            break;
            //����1.3 �ر�
           		      case("3"):
           		      			int removeNum=userInfo.getIndex(onlineUser, instruction.getOOnumber());
           		      			int MessageNum=Integer.valueOf(instruction.getParmNum());
           		      			this.onlineUser.remove(removeNum);
           		                conn.updateStatus(receOOnumber, "����");
           		                for(int i=0;i<MessageNum;i++) {
           		                	mconn.AddMessage(Message.toMessage(parameter.get(i)));
           		                }
           		                break;
           		      }
           		      break;
           	case("2"):switch(instruction.getSubInstruction()) {
           	//����2.1 ��������
           		      case("1"):String searching=parameter.get(0);
           		      	 		int intsearching=Integer.valueOf(searching);
           		      	 		if(!conn.getNickname(intsearching).equals("")) {
           		                String sendNickName=searching+":"+conn.getNickname(intsearching);
           		                byte[] searchMessage=sendNickName.getBytes();
            		            DatagramPacket searchPack=new DatagramPacket(searchMessage,searchMessage.length,InetAddress.getByName(instruction.getTrueIp()),10001);
            		            sendSocket.send(searchPack);
        		                }
           		      	 		else{
           		      	 			byte[] searchMessage="0".getBytes();
                		            DatagramPacket searchPack=new DatagramPacket(searchMessage,searchMessage.length,InetAddress.getByName(instruction.getTrueIp()),10001);
                		            sendSocket.send(searchPack);
               		            }
        		                break;
            //����2.2 �޸���Ϣ
           		      case("2"):int reOOnumber=Integer.valueOf(instruction.getOOnumber());
           		    	        conn.updateNickname(reOOnumber, parameter.get(0));
           		      			conn.updateSex(reOOnumber, parameter.get(1));
           		      			conn.updateBirthyear(reOOnumber, Integer.valueOf(parameter.get(2)));
           		      			conn.updateBirthmonth(reOOnumber,Integer.valueOf(parameter.get(3)));
           		      			conn.updateBirthday(reOOnumber, Integer.valueOf(parameter.get(4)));
           		      			conn.updateStatus(reOOnumber, parameter.get(5));
           		      			break;
           		      			
            //����2.3 ��ȡ������Ϣ
           		      case("3"):Instruction reaction=new Instruction("0","0",instruction.getTrueIp(),"6");
           		      			reaction.addParemeter(conn.getNickname(Integer.valueOf(instruction.getOOnumber())));
           		      			reaction.addParemeter(conn.getBirthyear(Integer.valueOf(instruction.getOOnumber())).toString());
           		      			reaction.addParemeter(conn.getBirthmonth(Integer.valueOf(instruction.getOOnumber())).toString());
           		      			reaction.addParemeter(conn.getBirthday(Integer.valueOf(instruction.getOOnumber())).toString());
           		      			reaction.addParemeter(conn.getSex(Integer.valueOf(instruction.getOOnumber())));
           		      			reaction.addParemeter(conn.getStatus(Integer.valueOf(instruction.getOOnumber())));
           		                byte[] userInfo=reaction.toString().getBytes();
        		                DatagramPacket userInfoPack=new DatagramPacket(userInfo,userInfo.length,InetAddress.getByName(instruction.getTrueIp()),10001);
        		                sendSocket.send(userInfoPack);
        		                break;
            //����2.4 �޸�����
           		      case("4"):int oonum=Integer.valueOf(instruction.getOOnumber());
           		    	  		String password=conn.getPassword(oonum);
           		    	  		String react=new String();
           		    	  		if(password.equals(parameter.get(0))) {
           		    	  			conn.updatePW(oonum, parameter.get(1));
           		    	  			react="1";
           		    	  		}
           		    	  		else {
           		    	  			react="0";
           		    	  		}
           		                byte[] by=react.toString().getBytes();
        		                DatagramPacket PasswordPack=new DatagramPacket(by,by.length,InetAddress.getByName(instruction.getTrueIp()),10001);
        		                sendSocket.send(PasswordPack);
        		                break;
             //����2.5 ���Ӻ���
           		      case("5"):int myoonum=Integer.valueOf(instruction.getOOnumber());
           		      			int youroonum=Integer.valueOf(parameter.get(0));
 		    	  				Integer AddResult=fconn.AddFriend(myoonum, youroonum);
           		                byte[] Result=AddResult.toString().getBytes();
        		                DatagramPacket AddResultPack=new DatagramPacket(Result,Result.length,InetAddress.getByName(instruction.getTrueIp()),10001);
        		                sendSocket.send(AddResultPack);
		               			break;
                      }
           			  break;
           	//����3.1 ת����Ϣ
           	case("3"):switch(instruction.getSubInstruction()) {
           			  case("1"):
           				  		int targetOOnumber=Integer.valueOf(parameter.get(0));
           				  		int myOOnumber=Integer.valueOf(instruction.getOOnumber());
          				  		String message=parameter.get(1);
           				  		if(!conn.getStatus(targetOOnumber).equals("����")) {
           				  		String targetIp=userInfo.getIp(onlineUser, parameter.get(0));
               		            Instruction onlineMessage=new Instruction("9","0",instruction.getIp(),instruction.getOOnumber(),instruction.getDate(),"2");
               		            onlineMessage.addParemeter(parameter.get(0));//����0ΪĿ��OO��
               		            onlineMessage.addParemeter(message);//����1Ϊ���͵���Ϣ
           		                byte[] onlineMe=onlineMessage.toString().getBytes();
        		                DatagramPacket onlineMessagePack=new DatagramPacket(onlineMe,onlineMe.length,InetAddress.getByName(targetIp),10002);
        		                sendSocket.send(onlineMessagePack);
           				  		}
           				  		else {
           				  		Message g=new Message(myOOnumber,targetOOnumber,message,0);
           				  		g.setDate(instruction.getDate());
           				  		mconn.AddMessage(g);
           				  		}
           				  		break;
           			  case("2"):
           				  		int myid=Integer.valueOf(instruction.getOOnumber());
           			  			int yourid=Integer.valueOf(parameter.get(0));
           				  		ArrayList<Message> AtoB=mconn.getHistoricalMessages(myid, yourid);
           				  		ArrayList<Message> BtoA=mconn.getHistoricalMessages(yourid, myid);
           				  		AtoB.addAll(BtoA);
           				  		AtoB.sort(c);
              			    	Instruction backins=new Instruction("7","0","192.168.1.16",instruction.getOOnumber(),"0");
              			    	for(int i=0;i<AtoB.size();i++) {
              			    		backins.addParemeter(AtoB.get(i).toString());
              			    	}
              			    	backins.setParmNum(AtoB.size());
           		                byte[] historyMessage=backins.toString().getBytes();
        		                DatagramPacket historyPack=new DatagramPacket(historyMessage,historyMessage.length,InetAddress.getByName(instruction.getTrueIp()),10001);
        		                sendSocket.send(historyPack);
        		                break;
           				  		}
           						
           	}
   			}
       }
	public Comparator c = new Comparator<Message>() {  
        @Override  
        public int compare(Message o1, Message o2) {  
            // TODO Auto-generated method stub  
            if(o1.getDate().compareTo(o2.getDate())==-1)  
                return -1;  
            //ע�⣡������ֵ������һ���෴����������Ч��jdk1.7�Ժ����������  
    //      else return 0; //��Ч  
            else return 1;  
        }  
   };
	public void close() throws IOException {
		this.serversocket.close();
		this.mconn.close();
		this.conn.close();
		this.fconn.close();
	}
}


